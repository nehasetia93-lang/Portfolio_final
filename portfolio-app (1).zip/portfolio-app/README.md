# Portfolio Dashboard – Deployment Guide

## What's in this folder
```
portfolio-app/
├── index.html
├── vite.config.js
├── package.json
├── public/
│   └── manifest.json       ← makes it installable on iPhone
└── src/
    ├── main.jsx
    └── App.jsx             ← the full dashboard
```

---

## Step 1 — Get a free Vercel account
1. Go to vercel.com
2. Sign up with Google or GitHub (either works)

---

## Step 2 — Upload your project

### Option A: Via GitHub (recommended — easiest to update later)
1. Go to github.com → sign up for free
2. Click **New repository** → name it `portfolio-dashboard` → Create
3. Upload all files in this folder (drag and drop into GitHub)
4. Go to vercel.com → **Add New Project** → Import from GitHub
5. Select your repo → click **Deploy**
6. Done! You'll get a URL like `portfolio-dashboard.vercel.app`

### Option B: Via Vercel CLI (if you're comfortable with Terminal)
```bash
npm install -g vercel
cd portfolio-app
npm install
vercel
```
Follow the prompts — it deploys automatically.

---

## Step 3 — Add to iPhone Home Screen
1. Open your Vercel URL in Safari on iPhone
2. Tap the **Share** button (box with arrow)
3. Tap **"Add to Home Screen"**
4. Tap **Add**

It will appear as an app icon on your home screen and open full-screen
(no browser chrome) — just like a native app.

---

## Data Storage
- All data is saved to your iPhone's **localStorage**
- This means data is stored in Safari on your phone
- ⚠️ Clearing Safari data or switching browsers will clear your data
- Use the **Export** button in the app regularly to download a backup JSON file

## To restore from a backup
Currently manual — open the JSON file, the data is all there in readable format.
(A future version can add an import button.)

---

## Updating the app
If you use GitHub: edit `src/App.jsx` on GitHub → Vercel auto-redeploys in ~30 seconds.

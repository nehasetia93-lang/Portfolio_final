import { useState, useEffect, useCallback } from "react";
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, RadialBarChart, RadialBar, AreaChart, Area } from "recharts";

// ─── Constants ────────────────────────────────────────────────────────────────
const MONTHS = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
const STATUSES = ["Pending","Done","Auto"];
const CM = new Date().getMonth();
const CY = new Date().getFullYear();
const KITE_URL = "https://api.kite.trade";

const INV_CATS = ["SIP","Gold ETF","REIT","Govt Bonds","Equity","Real Estate","Savings","Other"];
const EXP_CATS = ["Housing","Food","Transport","Insurance","Utilities","Savings","Lifestyle","Travel","Household","Joint","Other"];

const CAT_CLR = {
  SIP:"#B07D2A","Gold ETF":"#C8960A",REIT:"#2A7FA8","Govt Bonds":"#2E8B57",
  Equity:"#B85C2A","Real Estate":"#7A5EA8",Savings:"#2A8A8A",Other:"#7A8A90"
};
const EXP_CLR = {
  Housing:"#C05050",Food:"#C07830",Transport:"#4878A8",Insurance:"#8A56A8",
  Utilities:"#3A9858",Savings:"#8A8A20",Lifestyle:"#B84878",Travel:"#3888B8",
  Household:"#9A7040",Joint:"#5878A0",Other:"#708090"
};
const PC = { neha:"#B07D2A", sanket:"#2A7FA8" };
const KITE_INIT = { step:1, apiKey:"", apiSecret:"", token:"", reqToken:"", profile:null, holdings:[], synced:null, loading:false, err:"" };
const SS = {
  Done:    { bg:"#B07D2A20", c:"#8A5E1A", b:"#B07D2A50", i:"✓" },
  Auto:    { bg:"#2A7FA820", c:"#1A5F80", b:"#2A7FA850", i:"⟳" },
  Pending: { bg:"transparent", c:"#C8C0B0", b:"#E0D8CC", i:"·" }
};

// ─── Defaults ─────────────────────────────────────────────────────────────────
const D_NEHA_INV = [
  // ── Manually tracked ──
  {id:"ni2",name:"Digital Gold ETF",category:"Gold ETF",amount:2000},
  {id:"ni3",name:"Mindspace REIT",category:"REIT",amount:2000},
  {id:"ni4",name:"PPF – Neha",category:"Savings",amount:4000},
  // ── Zerodha Coin SIPs – auto-populated when Zerodha is connected ──
  {id:"nz1",name:"Coin SIP 1",category:"SIP",amount:0,zerodha:true},
  {id:"nz2",name:"Coin SIP 2",category:"SIP",amount:0,zerodha:true},
  {id:"nz3",name:"Coin SIP 3",category:"SIP",amount:0,zerodha:true},
  {id:"nz4",name:"Coin SIP 4",category:"SIP",amount:0,zerodha:true},
  {id:"nz5",name:"Coin SIP 5",category:"SIP",amount:0,zerodha:true},
  // ── Zerodha Kite Equity Holdings by Sector – auto-populated when Zerodha is connected ──
  {id:"ne1",name:"IT & Technology",category:"Equity",amount:0,zerodha:true,sector:"IT"},
  {id:"ne2",name:"FMCG & Consumer Goods",category:"Equity",amount:0,zerodha:true,sector:"FMCG"},
  {id:"ne3",name:"Banking & Financials",category:"Equity",amount:0,zerodha:true,sector:"Banking"},
  {id:"ne4",name:"Pharma & Healthcare",category:"Equity",amount:0,zerodha:true,sector:"Pharma"},
  {id:"ne5",name:"Auto & EV",category:"Equity",amount:0,zerodha:true,sector:"Auto"},
  {id:"ne6",name:"Energy & Power",category:"Equity",amount:0,zerodha:true,sector:"Energy"},
  {id:"ne7",name:"Infrastructure & Construction",category:"Equity",amount:0,zerodha:true,sector:"Infra"},
  {id:"ne8",name:"Metals & Mining",category:"Equity",amount:0,zerodha:true,sector:"Metals"},
  {id:"ne9",name:"Telecom & Media",category:"Equity",amount:0,zerodha:true,sector:"Telecom"},
  {id:"ne10",name:"Real Estate & REITs",category:"Equity",amount:0,zerodha:true,sector:"Realty"},
  {id:"ne11",name:"Chemicals & Specialty",category:"Equity",amount:0,zerodha:true,sector:"Chemicals"},
  {id:"ne12",name:"Midcap & Smallcap – Others",category:"Equity",amount:0,zerodha:true,sector:"Midcap"},
];
const D_SANKET_INV = [{id:"si1",name:"SIP – Sanket",category:"SIP",amount:25000}];
const D_NEHA_EXP = [
  {id:"ne1",name:"Home EMI",amount:35000,cat:"Housing"},
  {id:"ne2",name:"Travel Fund",amount:10000,cat:"Travel"},
  {id:"ne3",name:"Subscriptions",amount:5000,cat:"Lifestyle"},
  {id:"ne4",name:"Joint Account Transfer",amount:20000,cat:"Joint"},
  {id:"ne5",name:"Emergency Fund Top-up",amount:20000,cat:"Savings"},
];
const D_SANKET_EXP = [
  {id:"se1",name:"Rent",amount:32000,cat:"Housing"},
  {id:"se2",name:"Groceries",amount:10000,cat:"Food"},
  {id:"se3",name:"Maids",amount:10000,cat:"Household"},
  {id:"se4",name:"Health Insurance",amount:1000,cat:"Insurance"},
  {id:"se5",name:"Fuel",amount:5000,cat:"Transport"},
  {id:"se6",name:"Car EMI",amount:20000,cat:"Transport"},
  {id:"se7",name:"Life Insurance",amount:2000,cat:"Insurance"},
  {id:"se8",name:"Electricity, RO, Misc",amount:5000,cat:"Utilities"},
  {id:"se9",name:"Travel",amount:1000,cat:"Travel"},
  {id:"se10",name:"Home EMI",amount:35000,cat:"Housing"},
  {id:"se11",name:"Fixed Expenses",amount:70000,cat:"Other"},
];

// ─── Helpers ──────────────────────────────────────────────────────────────────
const fmt   = n => !n?"₹0":n>=100000?`₹${(n/100000).toFixed(1)}L`:n>=1000?`₹${Math.round(n/1000)}K`:`₹${n}`;
const fmtF  = n => `₹${(n||0).toLocaleString("en-IN")}`;
const fmtTs = d => { if(!d) return ""; const dt=new Date(d); return dt.toLocaleString("en-IN",{day:"2-digit",month:"short",hour:"2-digit",minute:"2-digit"}); };
const fmtSv = d => { if(!d) return ""; const dt=new Date(d); return `Saved ${dt.toLocaleDateString("en-IN",{day:"2-digit",month:"short"})} ${dt.toLocaleTimeString("en-IN",{hour:"2-digit",minute:"2-digit"})}`; };
const sumAmt = a => a.reduce((s,x)=>s+(x.amount||0),0);
const uid    = () => `${Date.now()}_${Math.random().toString(36).slice(2,6)}`;
async function sha256(str) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(str));
  return Array.from(new Uint8Array(buf)).map(x=>x.toString(16).padStart(2,"0")).join("");
}

// ─── Global CSS ───────────────────────────────────────────────────────────────
const CSS = `
@import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;0,600;1,300;1,400&family=Outfit:wght@300;400;500;600;700&family=IBM+Plex+Mono:wght@300;400;500&display=swap');

*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

:root {
  --bg:    #F2EDE4;
  --bg2:   #EDE7DC;
  --card:  #FDFAF6;
  --brd:   #E2D9CC;
  --brd2:  #D4C9B8;
  --text:  #1C1610;
  --sub:   #6B5E4A;
  --dim:   #9A8C7A;
  --gold:  #B07D2A;
  --blue:  #2A7FA8;
  --green: #2E8B57;
  --red:   #B84040;
}

body { background: var(--bg); font-family: 'Outfit', sans-serif; color: var(--text); }

/* Typography */
.cg  { font-family: 'Cormorant Garamond', Georgia, serif; }
.out { font-family: 'Outfit', sans-serif; }
.mono{ font-family: 'IBM Plex Mono', monospace; }

/* Scrollbar */
::-webkit-scrollbar { width: 4px; height: 4px; }
::-webkit-scrollbar-track { background: var(--bg2); }
::-webkit-scrollbar-thumb { background: var(--brd2); border-radius: 4px; }

/* Cards */
.card {
  background: var(--card);
  border: 1px solid var(--brd);
  border-radius: 18px;
  box-shadow: 0 1px 4px rgba(60,40,10,.05), 0 4px 20px rgba(60,40,10,.04);
  transition: box-shadow .2s, border-color .2s;
}
.card:hover { border-color: var(--brd2); box-shadow: 0 2px 8px rgba(60,40,10,.08), 0 8px 32px rgba(60,40,10,.06); }

/* Metric cards */
.mc {
  background: var(--card);
  border: 1px solid var(--brd);
  border-radius: 16px;
  padding: 20px 22px 18px;
  box-shadow: 0 1px 4px rgba(60,40,10,.05);
  transition: transform .18s, box-shadow .18s;
  position: relative;
  overflow: hidden;
}
.mc::after {
  content: '';
  position: absolute;
  bottom: 0; left: 0; right: 0;
  height: 3px;
  background: var(--acc, var(--gold));
  opacity: .5;
  border-radius: 0 0 16px 16px;
}
.mc:hover { transform: translateY(-2px); box-shadow: 0 4px 16px rgba(60,40,10,.10); }

/* Label */
.lbl { font-size: 10px; font-weight: 600; letter-spacing: .16em; text-transform: uppercase; color: var(--dim); font-family: 'Outfit', sans-serif; }

/* Inputs */
.inp {
  background: var(--bg);
  border: 1px solid var(--brd2);
  color: var(--text);
  border-radius: 10px;
  padding: 10px 13px;
  font-family: 'Outfit', sans-serif;
  font-size: 14px;
  width: 100%;
  outline: none;
  transition: border-color .15s, box-shadow .15s;
}
.inp:focus { border-color: var(--gold); box-shadow: 0 0 0 3px rgba(176,125,42,.10); }
.inp::placeholder { color: var(--dim); opacity: .5; }
.inp option { background: var(--bg); }

/* Buttons */
.bg {
  background: linear-gradient(135deg, #C49030, #8A5E18);
  color: #FFF8EC;
  border: none; border-radius: 10px; padding: 10px 22px;
  font-family: 'Outfit', sans-serif; font-size: 13px; font-weight: 600;
  cursor: pointer; transition: opacity .15s, transform .15s, box-shadow .15s;
  box-shadow: 0 2px 8px rgba(176,125,42,.25);
}
.bg:hover { opacity: .92; transform: translateY(-1px); box-shadow: 0 4px 14px rgba(176,125,42,.35); }
.bg:disabled { opacity: .4; cursor: not-allowed; transform: none; box-shadow: none; }
.bg-blue { background: linear-gradient(135deg, #3390BC, #1A6080); box-shadow: 0 2px 8px rgba(42,127,168,.25); }
.bg-blue:hover { box-shadow: 0 4px 14px rgba(42,127,168,.35); }

.gh {
  background: var(--bg);
  border: 1px solid var(--brd2);
  color: var(--sub);
  border-radius: 10px; padding: 9px 18px;
  font-family: 'Outfit', sans-serif; font-size: 13px; font-weight: 500;
  cursor: pointer; transition: all .15s;
}
.gh:hover { border-color: var(--gold); color: var(--gold); background: rgba(176,125,42,.04); }

.bd {
  background: transparent; border: 1px solid #DDBBBB;
  color: #B05050; border-radius: 10px; padding: 8px 14px;
  font-family: 'Outfit', sans-serif; font-size: 12px; cursor: pointer;
  transition: all .15s;
}
.bd:hover { background: rgba(184,64,64,.06); border-color: var(--red); }

/* Tabs */
.tab {
  padding: 13px 26px;
  font-family: 'Outfit', sans-serif; font-size: 14px; font-weight: 500;
  cursor: pointer; border: none; background: transparent;
  color: var(--dim); border-bottom: 2px solid transparent;
  transition: all .18s; letter-spacing: .01em;
}
.tab.an { color: var(--gold); border-bottom-color: var(--gold); font-weight: 600; }
.tab.as { color: var(--blue); border-bottom-color: var(--blue); font-weight: 600; }
.tab.ac { color: var(--sub); border-bottom-color: var(--sub); font-weight: 600; }
.tab:hover:not(.an):not(.as):not(.ac) { color: var(--sub); }

/* Modal */
.mbg {
  position: fixed; inset: 0; background: rgba(28,22,16,.55);
  backdrop-filter: blur(12px); display: flex; align-items: center;
  justify-content: center; z-index: 1000; padding: 16px;
}
.mbox {
  background: var(--card); border: 1px solid var(--brd2);
  border-radius: 22px; padding: 32px; width: min(480px,100%);
  max-height: 90vh; overflow-y: auto;
  box-shadow: 0 20px 60px rgba(28,22,16,.18);
}

/* Table cells */
.cb {
  cursor: pointer; border: none; outline: none;
  font-family: 'IBM Plex Mono', monospace;
  transition: transform .1s; line-height: 1; border-radius: 7px;
}
.cb:hover { transform: scale(1.15); }

.si {
  background: var(--bg); border: 1px solid var(--brd);
  border-radius: 8px; padding: 5px 6px;
  font-family: 'IBM Plex Mono', monospace; font-size: 11px;
  color: var(--dim); width: 72px; text-align: center;
  outline: none; transition: all .15s;
}
.si:focus { border-color: var(--gold); color: var(--text); }
.si.hv { color: var(--gold); border-color: rgba(176,125,42,.35); font-weight: 500; }

.ni {
  background: transparent; border: none; border-bottom: 1px solid var(--brd);
  color: var(--sub); font-family: 'Outfit', sans-serif; font-size: 12px;
  width: 100%; outline: none; padding: 2px 0; transition: all .15s;
}
.ni:focus { border-bottom-color: var(--gold); color: var(--text); }
.ni::placeholder { color: var(--dim); opacity: .4; }

/* Editable inline */
.ed { cursor: text; border-radius: 5px; padding: 2px 5px; margin: -2px -5px; transition: background .12s; display: inline-block; }
.ed:hover { background: rgba(176,125,42,.08); }
.ei {
  background: var(--bg); border: 1px solid var(--gold);
  color: var(--text); border-radius: 7px; padding: 3px 8px;
  font-family: 'Outfit', sans-serif; font-size: 13px; outline: none;
  box-shadow: 0 0 0 3px rgba(176,125,42,.10);
}
.ei-a { width: 90px; font-family: 'IBM Plex Mono', monospace; font-size: 12px; text-align: center; }

.cs {
  background: var(--bg); border: 1px solid var(--brd2);
  border-radius: 5px; padding: 2px 6px; font-family: 'Outfit', sans-serif;
  font-size: 10px; font-weight: 600; outline: none; cursor: pointer;
  color: var(--sub);
}
.cs:focus { border-color: var(--gold); }

/* Table rows */
.ch { cursor: pointer; transition: background .1s; }
.ch:hover { background: rgba(176,125,42,.03); }
.tr { border-bottom: 1px solid var(--brd); transition: background .08s; }
.tr:hover { background: rgba(176,125,42,.03); }

.db { background: transparent; border: none; cursor: pointer; opacity: 0; transition: opacity .15s; padding: 4px 6px; border-radius: 5px; }
.tr:hover .db { opacity: .5; }
.db:hover { opacity: 1 !important; background: rgba(184,64,64,.08); }

/* Progress */
.pb { height: 6px; background: var(--bg2); border-radius: 4px; overflow: hidden; }
.pf { height: 100%; border-radius: 4px; transition: width .65s ease; }
.pb-thin { height: 3px; background: var(--bg2); border-radius: 2px; overflow: hidden; }
.pf-thin { height: 100%; border-radius: 2px; transition: width .65s ease; }

/* Float btn */
.fa {
  position: fixed; bottom: 26px; right: 26px; width: 52px; height: 52px;
  border-radius: 50%; border: none; cursor: pointer;
  display: flex; align-items: center; justify-content: center; font-size: 24px;
  box-shadow: 0 4px 20px rgba(176,125,42,.4); transition: transform .2s, box-shadow .2s; z-index: 99;
}
.fa:hover { transform: scale(1.1); box-shadow: 0 8px 28px rgba(176,125,42,.5); }

/* Step pill */
.sp { width: 26px; height: 26px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 11px; flex-shrink: 0; }

/* Skeleton */
@keyframes sk { 0%,100% { opacity: .3 } 50% { opacity: .7 } }
.sk { animation: sk 1.6s ease-in-out infinite; background: var(--brd2); border-radius: 6px; }

/* Badge */
.badge {
  display: inline-flex; align-items: center; gap: 4px;
  padding: 3px 9px; border-radius: 20px;
  font-family: 'Outfit', sans-serif; font-size: 10px; font-weight: 600;
  letter-spacing: .04em;
}

/* Insight box */
.insight-box {
  background: linear-gradient(135deg, rgba(176,125,42,.06), rgba(176,125,42,.02));
  border: 1px solid rgba(176,125,42,.18);
  border-radius: 14px; padding: 16px 18px;
}

/* Divider */
.div { height: 1px; background: var(--brd); margin: 0; }

@keyframes fadeUp { from { opacity:0; transform:translateY(8px); } to { opacity:1; transform:translateY(0); } }
.fu { animation: fadeUp .35s ease both; }

input[type=number]::-webkit-inner-spin-button { opacity: .3; }
`;

// ─── Editable Components ──────────────────────────────────────────────────────
function EditText({ value, onSave }) {
  const [edit, setEdit] = useState(false);
  const [v, setV] = useState(value);
  const save = () => { const t=v.trim(); if(t&&t!==value) onSave(t); else setV(value); setEdit(false); };
  if(edit) return <input className="ei" value={v} onChange={e=>setV(e.target.value)}
    onBlur={save} onKeyDown={e=>{if(e.key==="Enter")e.target.blur();if(e.key==="Escape"){setV(value);setEdit(false);}}}
    autoFocus style={{maxWidth:200}}/>;
  return <span className="ed out" style={{fontSize:13.5,color:"var(--text)",fontWeight:500}}
    onClick={()=>{setV(value);setEdit(true);}} title="Click to rename">{value}</span>;
}

function EditAmt({ value, onSave, color="var(--gold)" }) {
  const [edit, setEdit] = useState(false);
  const [v, setV] = useState(value);
  const save = () => { const n=parseInt(v); if(!isNaN(n)&&n!==value) onSave(n); else setV(value); setEdit(false); };
  if(edit) return <input className="ei ei-a" type="number" value={v} onChange={e=>setV(e.target.value)}
    onBlur={save} onKeyDown={e=>{if(e.key==="Enter")e.target.blur();if(e.key==="Escape"){setV(value);setEdit(false);}}}
    autoFocus/>;
  return <span className="ed mono" style={{fontSize:12,color,display:"block",textAlign:"center",fontWeight:500}}
    onClick={()=>{setV(value);setEdit(true);}} title="Click to edit">{fmt(value)}</span>;
}

function EditCat({ value, onSave, options, colors }) {
  const [edit, setEdit] = useState(false);
  const c = colors[value]||"#708090";
  if(edit) return <select className="cs" value={value}
    onChange={e=>{onSave(e.target.value);setEdit(false);}} onBlur={()=>setEdit(false)} autoFocus style={{color:c}}>
    {options.map(o=><option key={o} value={o}>{o}</option>)}
  </select>;
  return <span onClick={()=>setEdit(true)} title="Change category"
    style={{fontSize:10,fontWeight:700,color:c,cursor:"pointer",background:`${c}18`,
      padding:"3px 8px",borderRadius:5,letterSpacing:".05em",fontFamily:"Outfit",display:"inline-block"}}>
    {value}
  </span>;
}

// ─── Expense Insights Panel ───────────────────────────────────────────────────
function ExpenseInsights({ exp, salary }) {
  const total = sumAmt(exp);
  const pct   = salary>0 ? Math.round(total/salary*100) : 0;
  const byCat = EXP_CATS
    .map(cat=>({ cat, value: exp.filter(e=>e.cat===cat).reduce((s,e)=>s+e.amount,0) }))
    .filter(d=>d.value>0)
    .sort((a,b)=>b.value-a.value);
  const top3  = byCat.slice(0,3);
  const necessities = ["Housing","Food","Transport","Utilities","Insurance"]
    .reduce((s,c)=>s+exp.filter(e=>e.cat===c).reduce((ss,e)=>ss+e.amount,0),0);
  const discretionary = total - necessities;
  const necPct = total>0 ? Math.round(necessities/total*100) : 0;
  const discPct = 100-necPct;

  return (
    <div style={{display:"flex",flexDirection:"column",gap:14}}>
      {/* Spend split */}
      <div>
        <div style={{display:"flex",justifyContent:"space-between",marginBottom:8}}>
          <span className="out" style={{fontSize:11,color:"var(--dim)",fontWeight:600,letterSpacing:".1em",textTransform:"uppercase"}}>Needs vs Wants</span>
          <span className="mono" style={{fontSize:11,color:"var(--sub)"}}>{necPct}% / {discPct}%</span>
        </div>
        <div style={{height:10,borderRadius:6,overflow:"hidden",display:"flex",gap:2}}>
          <div style={{width:`${necPct}%`,background:"#B84040",transition:"width .6s"}}/>
          <div style={{width:`${discPct}%`,background:"#B8882A",transition:"width .6s"}}/>
        </div>
        <div style={{display:"flex",gap:16,marginTop:6}}>
          {[["Necessities","#B84040",fmtF(necessities)],["Discretionary","#B8882A",fmtF(discretionary)]].map(([l,c,v])=>(
            <div key={l} style={{display:"flex",alignItems:"center",gap:5}}>
              <div style={{width:6,height:6,borderRadius:2,background:c}}/>
              <span className="out" style={{fontSize:10,color:"var(--dim)"}}>{l}</span>
              <span className="mono" style={{fontSize:10,color:c,marginLeft:2}}>{v}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Top categories */}
      <div>
        <span className="out" style={{fontSize:11,color:"var(--dim)",fontWeight:600,letterSpacing:".1em",textTransform:"uppercase",display:"block",marginBottom:10}}>Top Categories</span>
        <div style={{display:"flex",flexDirection:"column",gap:9}}>
          {byCat.slice(0,5).map(({cat,value})=>{
            const c = EXP_CLR[cat]||"#708090";
            const w = total>0 ? Math.round(value/total*100) : 0;
            return (
              <div key={cat}>
                <div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}>
                  <div style={{display:"flex",alignItems:"center",gap:7}}>
                    <div style={{width:7,height:7,borderRadius:2,background:c}}/>
                    <span className="out" style={{fontSize:13,color:"var(--sub)",fontWeight:500}}>{cat}</span>
                  </div>
                  <div style={{display:"flex",alignItems:"center",gap:8}}>
                    <span className="out" style={{fontSize:10,color:"var(--dim)"}}>{w}%</span>
                    <span className="mono" style={{fontSize:12,color:"var(--text)",fontWeight:500}}>{fmtF(value)}</span>
                  </div>
                </div>
                <div className="pb-thin"><div className="pf-thin" style={{width:`${w}%`,background:c}}/></div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Alerts */}
      {salary>0 && (
        <div style={{display:"flex",flexDirection:"column",gap:7}}>
          {pct>70&&<div style={{background:"rgba(184,64,64,.08)",border:"1px solid rgba(184,64,64,.2)",borderRadius:10,padding:"9px 12px"}}>
            <span className="out" style={{fontSize:12,color:"#B84040"}}>⚠ Expenses are {pct}% of income — consider reviewing discretionary spending.</span>
          </div>}
          {necessities/salary>0.5&&<div style={{background:"rgba(184,136,42,.08)",border:"1px solid rgba(184,136,42,.2)",borderRadius:10,padding:"9px 12px"}}>
            <span className="out" style={{fontSize:12,color:"#A07020"}}>📌 Fixed costs are over 50% of take-home — limited financial flexibility.</span>
          </div>}
          {pct<=50&&salary>0&&<div style={{background:"rgba(46,139,87,.08)",border:"1px solid rgba(46,139,87,.2)",borderRadius:10,padding:"9px 12px"}}>
            <span className="out" style={{fontSize:12,color:"#2E7A50"}}>✓ Expenses at {pct}% of income — good budget discipline.</span>
          </div>}
        </div>
      )}
    </div>
  );
}

// ─── Investment Insights Panel ────────────────────────────────────────────────
function InvestmentInsights({ inv, salary, color }) {
  const total    = sumAmt(inv);
  const savR     = salary>0 ? Math.round(total/salary*100) : 0;
  const byCat    = INV_CATS
    .map(c=>({ c, v:inv.filter(i=>i.category===c).reduce((s,i)=>s+i.amount,0) }))
    .filter(d=>d.v>0);
  const diversified = byCat.length >= 3;
  const hasDebt  = inv.some(i=>["Govt Bonds","REIT"].includes(i.category));
  const hasGold  = inv.some(i=>i.category==="Gold ETF");

  // Projected value at 12% CAGR, 10 years
  const proj10yr = Math.round(total * 12 * ((Math.pow(1.12,10)-1)/0.01));

  const radData = byCat.map((d,i)=>({name:d.c,value:d.v,fill:CAT_CLR[d.c]||"#888"}));

  return (
    <div style={{display:"flex",flexDirection:"column",gap:14}}>
      {/* Allocation bars */}
      <div>
        <span className="out" style={{fontSize:11,color:"var(--dim)",fontWeight:600,letterSpacing:".1em",textTransform:"uppercase",display:"block",marginBottom:10}}>Allocation Breakdown</span>
        <div style={{display:"flex",flexDirection:"column",gap:8}}>
          {byCat.map(({c,v})=>{
            const cl = CAT_CLR[c]||"#888";
            const w  = total>0 ? Math.round(v/total*100) : 0;
            return (
              <div key={c}>
                <div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}>
                  <div style={{display:"flex",alignItems:"center",gap:7}}>
                    <div style={{width:7,height:7,borderRadius:2,background:cl}}/>
                    <span className="out" style={{fontSize:13,color:"var(--sub)",fontWeight:500}}>{c}</span>
                  </div>
                  <div style={{display:"flex",alignItems:"center",gap:8}}>
                    <span className="out" style={{fontSize:10,color:"var(--dim)"}}>{w}%</span>
                    <span className="mono" style={{fontSize:12,color:"var(--text)",fontWeight:500}}>{fmtF(v)}</span>
                  </div>
                </div>
                <div className="pb-thin"><div className="pf-thin" style={{width:`${w}%`,background:cl}}/></div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 10yr projection */}
      {total>0&&(
        <div style={{background:`${color}0A`,border:`1px solid ${color}25`,borderRadius:12,padding:"13px 15px"}}>
          <div className="out" style={{fontSize:11,color:color,fontWeight:600,marginBottom:4,opacity:.8}}>10-YR PROJECTION @ 12% CAGR</div>
          <div className="cg" style={{fontSize:28,color:color,fontWeight:400,lineHeight:1}}>{fmt(proj10yr)}</div>
          <div className="out" style={{fontSize:11,color:"var(--dim)",marginTop:4}}>If you keep investing {fmtF(total)}/mo consistently</div>
        </div>
      )}

      {/* Portfolio health */}
      <div>
        <span className="out" style={{fontSize:11,color:"var(--dim)",fontWeight:600,letterSpacing:".1em",textTransform:"uppercase",display:"block",marginBottom:8}}>Portfolio Health</span>
        <div style={{display:"flex",flexDirection:"column",gap:7}}>
          {[
            [diversified,"Diversified across 3+ asset classes","Concentrated in fewer than 3 asset types"],
            [hasDebt,"Debt component present (stability)","No bonds/REIT — consider adding debt for stability"],
            [hasGold,"Gold exposure as inflation hedge","No gold — consider adding 5–10% allocation"],
            [savR>=20,"Savings rate ≥ 20% — excellent","Savings rate below 20% — try to increase SIPs"],
          ].map(([ok,good,bad],i)=>(
            <div key={i} style={{display:"flex",alignItems:"flex-start",gap:9,padding:"8px 10px",
              background:ok?"rgba(46,139,87,.07)":"rgba(184,64,64,.05)",
              border:`1px solid ${ok?"rgba(46,139,87,.18)":"rgba(184,64,64,.15)"}`,borderRadius:9}}>
              <span style={{fontSize:14,flexShrink:0,marginTop:1}}>{ok?"✓":"○"}</span>
              <span className="out" style={{fontSize:12,color:ok?"#2E7050":"#B05050",lineHeight:1.5}}>{ok?good:bad}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Tracker Table ────────────────────────────────────────────────────────────
function TrackerTable({ rows, statusMap, notes, onToggle, onNote, onDelete, onUpdate, groupKey, groups, tagColors, accent }) {
  const [collapsed, setCollapsed] = useState({});
  const catOpts   = groupKey==="category" ? INV_CATS : EXP_CATS;
  const catColors = groupKey==="category" ? CAT_CLR  : EXP_CLR;
  const used = groups.filter(g=>rows.some(r=>r[groupKey]===g));

  if(!rows.length) return (
    <div style={{textAlign:"center",padding:"30px",color:"var(--dim)"}}>
      <div className="cg" style={{fontSize:20,marginBottom:4}}>Nothing here yet</div>
      <div className="out" style={{fontSize:13}}>Click + Add to add your first entry</div>
    </div>
  );

  const doneCount = rows.filter(r=>{ const s=statusMap[r.id]?.[CM]?.status||"Pending"; return s!=="Pending"; }).length;

  return (
    <div>
      {/* Progress summary */}
      <div style={{display:"flex",alignItems:"center",gap:16,marginBottom:14,padding:"10px 14px",
        background:"var(--bg)",borderRadius:10,border:"1px solid var(--brd)"}}>
        <div style={{flex:1}}>
          <div style={{display:"flex",justifyContent:"space-between",marginBottom:5}}>
            <span className="out" style={{fontSize:12,color:"var(--sub)",fontWeight:500}}>{MONTHS[CM]} Progress</span>
            <span className="mono" style={{fontSize:12,color:accent,fontWeight:500}}>{doneCount}/{rows.length} done</span>
          </div>
          <div className="pb"><div className="pf" style={{width:`${rows.length>0?Math.round(doneCount/rows.length*100):0}%`,background:accent}}/></div>
        </div>
        <div style={{display:"flex",gap:10}}>
          {[["✓","Done",accent],["⟳","Auto","var(--blue)"],["·","Pending","var(--dim)"]].map(([i,s,c])=>(
            <div key={s} style={{display:"flex",alignItems:"center",gap:4}}>
              <span style={{color:c,fontSize:13,fontFamily:"IBM Plex Mono"}}>{i}</span>
              <span className="out" style={{fontSize:10,color:"var(--dim)"}}>{s}</span>
            </div>
          ))}
        </div>
      </div>

      <div style={{overflowX:"auto",borderRadius:12,border:"1px solid var(--brd)"}}>
        <table style={{width:"100%",borderCollapse:"collapse",minWidth:1000}}>
          <thead>
            <tr style={{background:"var(--bg)"}}>
              <th style={{textAlign:"left",padding:"10px 16px",borderBottom:"1px solid var(--brd)",width:195}}>
                <span className="lbl" style={{fontSize:9}}>Name</span>
              </th>
              <th style={{textAlign:"left",padding:"10px 10px",borderBottom:"1px solid var(--brd)",width:100}}>
                <span className="lbl" style={{fontSize:9}}>Category</span>
              </th>
              <th style={{padding:"10px 6px",borderBottom:"1px solid var(--brd)",width:76,textAlign:"center"}}>
                <span className="lbl" style={{fontSize:9}}>₹/mo</span>
              </th>
              {MONTHS.map((m,i)=>(
                <th key={m} style={{padding:"10px 2px",borderBottom:"1px solid var(--brd)",minWidth:38,textAlign:"center"}}>
                  <span className="mono" style={{fontSize:9,color:i===CM?accent:"var(--dim)",fontWeight:i===CM?600:300,opacity:i===CM?1:.6}}>{m}</span>
                </th>
              ))}
              <th style={{padding:"10px 14px",borderBottom:"1px solid var(--brd)",width:130}}>
                <span className="lbl" style={{fontSize:9}}>Note</span>
              </th>
              <th style={{borderBottom:"1px solid var(--brd)",width:32}}/>
            </tr>
          </thead>
          <tbody>
            {used.map(grp=>{
              const gr  = rows.filter(r=>r[groupKey]===grp);
              if(!gr.length) return null;
              const ck  = `g:${grp}`;
              const open= !collapsed[ck];
              const gc  = tagColors[grp]||"#708090";
              const gt  = gr.reduce((s,r)=>s+(r.amount||0),0);
              const gd  = gr.filter(r=>{ const s=statusMap[r.id]?.[CM]?.status||"Pending"; return s!=="Pending"; }).length;
              return (
                <tr key={ck}><td colSpan={18} style={{padding:0}}>
                  <table style={{width:"100%",borderCollapse:"collapse"}}>
                    <tbody>
                      <tr className="ch" onClick={()=>setCollapsed(c=>({...c,[ck]:!c[ck]}))}>
                        <td colSpan={18} style={{padding:"8px 16px",borderBottom:"1px solid var(--brd)",background:"rgba(176,125,42,.03)"}}>
                          <div style={{display:"flex",alignItems:"center",gap:10}}>
                            <div style={{width:8,height:8,borderRadius:2,background:gc,flexShrink:0}}/>
                            <span className="cg" style={{fontSize:14,color:gc,fontStyle:"italic",fontWeight:500}}>{grp}</span>
                            <span className="out" style={{fontSize:10,color:"var(--dim)"}}>{gr.length} item{gr.length!==1?"s":""}</span>
                            <span className="out" style={{fontSize:10,color:"var(--dim)",marginLeft:4}}>{gd}/{gr.length} done</span>
                            <span className="mono" style={{fontSize:12,color:gc,marginLeft:"auto",fontWeight:500}}>{fmtF(gt)}</span>
                            <span className="out" style={{fontSize:9,color:"var(--dim)",marginLeft:10}}>{open?"▲":"▼"}</span>
                          </div>
                        </td>
                      </tr>
                      {open && gr.map(row=>{
                        const isZ = !!row.zerodha;
                        return (
                        <tr key={row.id} className="tr" style={{background:isZ?"rgba(46,139,87,.03)":"transparent",opacity:isZ&&row.amount===0?.65:1}}>
                          <td style={{padding:"8px 16px",width:195}}>
                            {isZ ? (
                              <div style={{display:"flex",alignItems:"center",gap:7}}>
                                <span className="out" style={{fontSize:12,color:"var(--dim)",fontStyle:"italic"}}>{row.name}</span>
                              </div>
                            ) : (
                              <EditText value={row.name} onSave={v=>onUpdate(row.id,"name",v)}/>
                            )}
                          </td>
                          <td style={{padding:"8px 10px",width:100}}>
                            {isZ ? (
                              <div style={{display:"flex",flexDirection:"column",gap:3}}>
                                <span style={{fontSize:10,fontWeight:700,color:"#2E8B57",background:"rgba(46,139,87,.1)",padding:"2px 7px",borderRadius:4,letterSpacing:".05em",fontFamily:"Outfit",display:"inline-flex",alignItems:"center",gap:4}}>
                                  <span style={{fontSize:9}}>⟳</span> Zerodha
                                </span>
                                {row.sector && <span style={{fontSize:9,fontWeight:700,color:CAT_CLR["Equity"]||"#B85C2A",background:"rgba(184,92,42,.1)",padding:"1px 6px",borderRadius:3,letterSpacing:".06em",fontFamily:"Outfit"}}>{row.sector}</span>}
                              </div>
                            ) : (
                              <EditCat value={row[groupKey]} onSave={v=>onUpdate(row.id,groupKey,v)} options={catOpts} colors={catColors}/>
                            )}
                          </td>
                          <td style={{padding:"8px 6px",textAlign:"center",width:76}}>
                            {isZ ? (
                              <span className="mono" style={{fontSize:12,color:row.amount>0?"#2E8B57":"var(--dim)",fontStyle:row.amount===0?"italic":"normal"}}>
                                {row.amount>0?fmt(row.amount):"—"}
                              </span>
                            ) : (
                              <EditAmt value={row.amount} onSave={v=>onUpdate(row.id,"amount",v)} color={accent}/>
                            )}
                          </td>
                          {MONTHS.map((_,mi)=>{
                            const ent = statusMap[row.id]?.[mi];
                            const st  = ent?.status||"Pending";
                            const s   = SS[st];
                            return (
                              <td key={mi} style={{padding:"5px 2px",textAlign:"center",
                                background:mi===CM?`${accent}09`:"transparent"}}>
                                {isZ&&row.amount===0 ? (
                                  <span style={{color:"var(--brd2)",fontSize:14,lineHeight:1}}>–</span>
                                ) : (
                                  <button className="cb" title={ent?.ts?`${st} · ${fmtTs(ent.ts)}`:st}
                                    onClick={()=>onToggle(row.id,mi)}
                                    style={{width:32,height:22,background:st!=="Pending"?s.bg:"transparent",
                                      border:`1px solid ${s.b}`,color:s.c,fontSize:st==="Auto"?10:12}}>
                                    {s.i}
                                  </button>
                                )}
                              </td>
                            );
                          })}
                          <td style={{padding:"8px 14px"}}>
                            {!isZ && <input className="ni" placeholder="note…" value={notes[row.id]||""} onChange={e=>onNote(row.id,e.target.value)}/>}
                            {isZ && <span className="out" style={{fontSize:11,color:"var(--dim)",fontStyle:"italic"}}>auto-filled</span>}
                          </td>
                          <td style={{padding:"8px 6px",textAlign:"center"}}>
                            {!isZ && (
                              <button className="db" onClick={()=>onDelete(row.id)} title="Remove">
                                <span style={{fontSize:16,color:"var(--red)",lineHeight:1}}>×</span>
                              </button>
                            )}
                          </td>
                        </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </td></tr>
              );
            })}
          </tbody>
        </table>
        <div style={{padding:"8px 16px",borderTop:"1px solid var(--brd)",background:"var(--bg)"}}>
          <span className="out" style={{fontSize:10,color:"var(--dim)"}}>Click cells to cycle status · Click name / ₹ / category to edit inline</span>
        </div>
      </div>
    </div>
  );
}

// ─── Zerodha Section ─────────────────────────────────────────────────────────
function ZerodhaSection({ kite, setKite, persist }) {
  const [showModal, setShowModal] = useState(false);
  const k = kite;
  const upd = p => { const nk={...k,...p}; setKite(nk); persist({nehaKite:nk}); };
  const saveCreds = () => { if(!k.apiKey||!k.apiSecret){upd({err:"Both fields required."}); return;} upd({step:2,err:""}); };
  const exchangeToken = async () => {
    if(!k.reqToken){upd({err:"Paste the request_token first."}); return;}
    upd({loading:true,err:""});
    try {
      const cs = await sha256(k.apiKey+k.reqToken+k.apiSecret);
      const body = new URLSearchParams({api_key:k.apiKey,request_token:k.reqToken,checksum:cs});
      const r = await fetch(`${KITE_URL}/session/token`,{method:"POST",headers:{"X-Kite-Version":"3","Content-Type":"application/x-www-form-urlencoded"},body});
      const d = await r.json();
      if(d.status!=="success") throw new Error(d.message||"Failed");
      await syncKite(k.apiKey, d.data.access_token);
    } catch(e) { upd({loading:false,err:e.message||"Exchange failed."}); }
  };
  const syncKite = async (apiKey, token) => {
    try {
      const h = {"X-Kite-Version":"3","Authorization":`token ${apiKey}:${token}`};
      const [pr,hr] = await Promise.all([fetch(`${KITE_URL}/user/profile`,{headers:h}),fetch(`${KITE_URL}/portfolio/holdings`,{headers:h})]);
      const [pd,hd] = await Promise.all([pr.json(),hr.json()]);
      if(pd.status!=="success") throw new Error(pd.message||"Auth failed");
      const nk = {...k,step:4,token,profile:pd.data,holdings:hd.data||[],synced:new Date().toISOString(),loading:false,err:""};
      setKite(nk); persist({nehaKite:nk});
    } catch(e) { upd({loading:false,err:e.message||"Sync failed."}); }
  };
  const disconnect = () => { setKite({...KITE_INIT}); persist({nehaKite:{...KITE_INIT}}); };

  const holdings = k.holdings||[];
  const kTotal   = holdings.reduce((s,h)=>s+(h.last_price||0)*h.quantity,0);
  const equity   = holdings.filter(h=>!h.tradingsymbol?.match(/ETF|BEES|LIQUID|GILT|FUND/i));
  const mf       = holdings.filter(h=>h.tradingsymbol?.match(/ETF|BEES|LIQUID|GILT|FUND/i));

  return (
    <>
      <div className="card" style={{padding:"22px",borderColor:k.step===4?"rgba(46,139,87,.35)":"var(--brd)"}}>
        <div style={{display:"flex",alignItems:"flex-start",justifyContent:"space-between",marginBottom:14}}>
          <div>
            <div className="lbl" style={{marginBottom:7}}>Zerodha Portfolio</div>
            <span className="badge" style={{background:k.step===4?"rgba(46,139,87,.12)":"var(--bg2)",color:k.step===4?"#2E7A50":"var(--dim)",border:`1px solid ${k.step===4?"rgba(46,139,87,.25)":"var(--brd2)"}`}}>
              {k.step===4?"● Live":"○ Not Connected"}
            </span>
          </div>
          {k.step===4&&k.synced&&<span className="out" style={{fontSize:10,color:"var(--dim)"}}>{fmtTs(k.synced)}</span>}
        </div>
        {k.step===4 ? (
          <div>
            {kTotal>0&&<div style={{marginBottom:14}}>
              <div className="cg" style={{fontSize:32,color:"var(--green)",fontWeight:400,lineHeight:1}}>{fmt(kTotal)}</div>
              <div className="out" style={{fontSize:11,color:"var(--dim)",marginTop:4}}>{holdings.length} holdings · {equity.length} equity · {mf.length} ETF/MF</div>
            </div>}
            {equity.length>0&&<div style={{marginBottom:12}}>
              <div className="lbl" style={{marginBottom:7,fontSize:8}}>Equity</div>
              {equity.slice(0,5).map(h=>(
                <div key={h.tradingsymbol} style={{display:"flex",justifyContent:"space-between",padding:"6px 0",borderBottom:"1px solid var(--brd)"}}>
                  <span className="out" style={{fontSize:13,color:"var(--sub)",fontWeight:500}}>{h.tradingsymbol}</span>
                  <span className="mono" style={{fontSize:12,color:"var(--green)",fontWeight:500}}>{fmtF((h.last_price||0)*h.quantity)}</span>
                </div>
              ))}
              {equity.length>5&&<div className="out" style={{fontSize:11,color:"var(--dim)",paddingTop:5}}>+{equity.length-5} more</div>}
            </div>}
            {mf.length>0&&<div style={{marginBottom:12}}>
              <div className="lbl" style={{marginBottom:7,fontSize:8}}>ETF / Demat MF</div>
              {mf.map(h=>(
                <div key={h.tradingsymbol} style={{display:"flex",justifyContent:"space-between",padding:"6px 0",borderBottom:"1px solid var(--brd)"}}>
                  <span className="out" style={{fontSize:13,color:"var(--sub)",fontWeight:500}}>{h.tradingsymbol}</span>
                  <span className="mono" style={{fontSize:12,color:"var(--green)",fontWeight:500}}>{fmtF((h.last_price||0)*h.quantity)}</span>
                </div>
              ))}
            </div>}
            <div className="out" style={{fontSize:11,color:"var(--dim)",marginBottom:12}}>Coin SIPs and equity holdings are fetched automatically from Zerodha.</div>
            {k.err&&<div className="out" style={{fontSize:12,color:"var(--red)",marginBottom:10}}>{k.err}</div>}
            <div style={{display:"flex",gap:8}}>
              <button className="bg" style={{flex:2,fontSize:12,padding:"8px 10px"}} onClick={()=>syncKite(k.apiKey,k.token)} disabled={k.loading}>{k.loading?"Syncing…":"↻ Sync Now"}</button>
              <button className="gh" style={{flex:1,fontSize:11}} onClick={()=>setShowModal(true)}>Settings</button>
              <button className="bd" onClick={disconnect}>Disconnect</button>
            </div>
          </div>
        ) : (
          <div>
            <div className="out" style={{fontSize:13,color:"var(--sub)",lineHeight:1.75,marginBottom:14}}>Connect Zerodha to auto-fetch equity holdings, ETF/demat MF data, and Coin SIPs — all populated automatically.</div>
            <button className="bg" style={{width:"100%"}} onClick={()=>setShowModal(true)}>Connect Zerodha Account</button>
          </div>
        )}
      </div>

      {showModal&&(
        <div className="mbg" onClick={e=>{if(e.target===e.currentTarget)setShowModal(false);}}>
          <div className="mbox">
            <div className="cg" style={{fontSize:28,color:"var(--gold)",fontWeight:400,marginBottom:4}}>Zerodha Connect</div>
            <div className="out" style={{fontSize:12,color:"var(--dim)",marginBottom:22}}>Kite Connect · Free Personal API · Credentials stay on your device</div>
            <div style={{display:"flex",alignItems:"center",gap:6,marginBottom:22}}>
              {["Creds","Login","Token","Live"].map((s,i)=>(
                <div key={s} style={{display:"flex",alignItems:"center",gap:5,flex:i<3?1:0}}>
                  <div className="sp" style={{background:k.step>i+1?"rgba(46,139,87,.15)":k.step===i+1?"rgba(176,125,42,.15)":"var(--bg2)",color:k.step>i+1?"var(--green)":k.step===i+1?"var(--gold)":"var(--dim)",border:`1px solid ${k.step>i+1?"rgba(46,139,87,.3)":k.step===i+1?"rgba(176,125,42,.3)":"var(--brd2)"}`,fontSize:11}}>{k.step>i+1?"✓":i+1}</div>
                  <span className="out" style={{fontSize:11,color:k.step===i+1?"var(--gold)":k.step>i+1?"var(--green)":"var(--dim)"}}>{s}</span>
                  {i<3&&<div style={{flex:1,height:1,background:k.step>i+1?"rgba(46,139,87,.25)":"var(--brd)"}}/>}
                </div>
              ))}
            </div>
            {k.step===1&&<><div className="out" style={{fontSize:13,color:"var(--sub)",lineHeight:1.85,marginBottom:16}}>
              1. Go to <span style={{color:"var(--gold)"}}>kite.zerodha.com/connect/apps</span><br/>
              2. Create app → type: <strong>Personal</strong> (free)<br/>
              3. Redirect URL: <span style={{color:"var(--gold)"}}>https://localhost</span><br/>
              4. Copy API Key + Secret below
            </div>
            <div style={{display:"flex",flexDirection:"column",gap:10}}>
              <input className="inp" placeholder="API Key" value={k.apiKey} onChange={e=>upd({apiKey:e.target.value})}/>
              <input className="inp" type="password" placeholder="API Secret" value={k.apiSecret} onChange={e=>upd({apiSecret:e.target.value})}/>
              {k.err&&<div className="out" style={{fontSize:12,color:"var(--red)"}}>{k.err}</div>}
              <div style={{display:"flex",gap:8}}><button className="bg" style={{flex:1}} onClick={saveCreds}>Continue →</button><button className="gh" style={{flex:1}} onClick={()=>setShowModal(false)}>Cancel</button></div>
            </div></>}
            {k.step===2&&<><div className="out" style={{fontSize:13,color:"var(--sub)",lineHeight:1.85,marginBottom:16}}>Click to open Kite login. After authenticating, copy the <span style={{color:"var(--gold)"}}>request_token</span> from the redirect URL and paste below.</div>
            <div style={{display:"flex",flexDirection:"column",gap:10}}>
              <a href={`https://kite.zerodha.com/connect/login?api_key=${k.apiKey}&v=3`} target="_blank" rel="noreferrer" style={{textDecoration:"none"}}><button className="bg" style={{width:"100%"}}>Open Kite Login ↗</button></a>
              <input className="inp" placeholder="Paste request_token from redirect URL" value={k.reqToken} onChange={e=>upd({reqToken:e.target.value})}/>
              {k.err&&<div className="out" style={{fontSize:12,color:"var(--red)"}}>{k.err}</div>}
              <div style={{display:"flex",gap:8}}><button className="bg" style={{flex:1}} onClick={()=>upd({step:3})}>Next →</button><button className="gh" style={{flex:1}} onClick={()=>upd({step:1})}>← Back</button></div>
            </div></>}
            {k.step===3&&<><div className="out" style={{fontSize:13,color:"var(--sub)",lineHeight:1.85,marginBottom:16}}>Computing SHA-256 checksum locally and exchanging for an access token. Credentials never leave this device.</div>
            {k.err&&<div className="out" style={{fontSize:12,color:"var(--red)",marginBottom:12}}>{k.err}</div>}
            <div style={{display:"flex",gap:8}}><button className="bg" style={{flex:1}} onClick={exchangeToken} disabled={k.loading}>{k.loading?"Connecting…":"Connect Account"}</button><button className="gh" style={{flex:1}} onClick={()=>upd({step:2})}>← Back</button></div></>}
            {k.step===4&&<><div style={{background:"rgba(46,139,87,.08)",border:"1px solid rgba(46,139,87,.2)",borderRadius:12,padding:"14px",marginBottom:14}}>
              <div className="out" style={{fontSize:13,color:"var(--green)",marginBottom:4,fontWeight:600}}>✓ Connected</div>
              {k.profile&&<div className="out" style={{fontSize:12,color:"var(--sub)"}}>{k.profile.user_name} · {k.profile.email}</div>}
            </div>
            <div style={{display:"flex",gap:8}}><button className="bg" style={{flex:2}} onClick={()=>syncKite(k.apiKey,k.token)}>Sync Portfolio</button><button className="bd" style={{flex:1}} onClick={disconnect}>Disconnect</button></div></>}
            <button className="gh" style={{width:"100%",marginTop:10,fontSize:12}} onClick={()=>setShowModal(false)}>Close</button>
          </div>
        </div>
      )}
    </>
  );
}

// ─── AI Insights ─────────────────────────────────────────────────────────────
function AIInsights({ data }) {
  const [analysis, setAnalysis] = useState("");
  const [loading,  setLoading]  = useState(false);
  const [done,     setDone]     = useState(false);
  const { nehaS,sanketS,nehaInvT,sanketInvT,nehaExpT,sanketExpT,totalInv,totalExp,net,nehaInv,sanketInv,nehaExp,sanketExp,kiteTotal } = data;
  const totalSal = nehaS+sanketS;

  const run = async () => {
    setLoading(true); setAnalysis(""); setDone(false);
    const prompt = `You are a sharp, direct personal finance advisor for an Indian couple. Month: ${MONTHS[CM]} ${CY}.
Income — Neha: ₹${nehaS.toLocaleString("en-IN")} | Sanket: ₹${sanketS.toLocaleString("en-IN")} | Combined: ₹${totalSal.toLocaleString("en-IN")}
Investments — Neha: ${nehaInv.map(i=>`${i.name} ₹${i.amount.toLocaleString("en-IN")}`).join(", ")} | Sanket: ${sanketInv.map(i=>`${i.name} ₹${i.amount.toLocaleString("en-IN")}`).join(", ")} | Total: ₹${totalInv.toLocaleString("en-IN")}/mo
Expenses — Neha: ${nehaExp.map(e=>`${e.name} ₹${e.amount.toLocaleString("en-IN")}`).join(", ")} | Sanket: ${sanketExp.map(e=>`${e.name} ₹${e.amount.toLocaleString("en-IN")}`).join(", ")}
Savings rate: ${totalSal>0?Math.round(totalInv/totalSal*100):0}% | Net: ₹${net.toLocaleString("en-IN")}${kiteTotal>0?` | Zerodha equity: ₹${kiteTotal.toLocaleString("en-IN")}`:""}
Give 5 numbered insights: (1) portfolio rebalancing, (2) expense reduction opportunity, (3) joint financial goal to set, (4) tax optimisation (80C, NPS, ELSS, HRA), (5) one specific action for next month. Use **bold** for key numbers and actions. 2-3 sentences each.`;
    try {
      const r = await fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({model:"claude-sonnet-4-20250514",max_tokens:700,messages:[{role:"user",content:prompt}]})});
      const d = await r.json();
      setAnalysis(d.content?.[0]?.text||"No response."); setDone(true);
    } catch(e) { setAnalysis("Analysis failed. Check your connection."); setDone(true); }
    setLoading(false);
  };

  const render = t => t.split(/(\*\*[^*]+\*\*)/).map((p,i)=>
    p.startsWith("**")&&p.endsWith("**") ? <strong key={i} style={{color:"var(--gold)",fontWeight:600}}>{p.slice(2,-2)}</strong> : <span key={i}>{p}</span>
  );

  return (
    <div className="card" style={{padding:"28px",borderColor:"rgba(176,125,42,.25)"}}>
      <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:18}}>
        <div>
          <div className="cg" style={{fontSize:26,color:"var(--gold)",fontWeight:400,marginBottom:3}}>AI Financial Insights</div>
          <div className="out" style={{fontSize:13,color:"var(--dim)"}}>Personalised advice based on your actual data</div>
        </div>
        <button className="bg" onClick={run} disabled={loading||totalSal===0} style={{fontSize:12,minWidth:110}}>
          {loading?"Analysing…":done?"↻ Refresh":"✦ Analyse"}
        </button>
      </div>
      {totalSal===0&&!done&&<div className="out" style={{fontSize:13,color:"var(--dim)",textAlign:"center",padding:"20px 0"}}>Enter salary figures first to generate personalised insights</div>}
      {loading&&<div style={{display:"flex",flexDirection:"column",gap:12}}>{[70,55,80,60,75].map((w,i)=><div key={i} className="sk" style={{height:14,width:`${w}%`}}/>)}</div>}
      {!loading&&analysis&&<div className="out" style={{fontSize:14,lineHeight:1.9,color:"var(--sub)",whiteSpace:"pre-wrap"}}>{render(analysis)}</div>}
    </div>
  );
}

// ─── Person Tab ───────────────────────────────────────────────────────────────
function PersonTab({ person, salary, inv, setInv, exp, setExp, invSt, setInvSt, expSt, setExpSt, sal, setSal, notes, setNotes, kite, setKite, changeLog, setChangeLog, persist }) {
  const color = PC[person];
  const [invOpen, setInvOpen] = useState(true);
  const [expOpen, setExpOpen] = useState(true);
  const [salOpen, setSalOpen] = useState(false);
  const [modal,   setModal]   = useState(null);
  const [newInv,  setNewInv]  = useState({name:"",category:"SIP",amount:""});
  const [newExp,  setNewExp]  = useState({name:"",amount:"",cat:"Housing"});

  const totalInv = sumAmt(inv);
  const totalExp = sumAmt(exp);
  const net      = salary - totalInv - totalExp;
  const savR     = salary>0 ? Math.round(totalInv/salary*100) : 0;
  const kiteTotal= person==="neha" ? (kite.holdings||[]).reduce((s,h)=>s+(h.last_price||0)*h.quantity,0) : 0;

  const donutData = salary>0 ? [
    {name:"Invested",value:totalInv,color},
    {name:"Expenses",value:totalExp,color:"var(--blue)"},
    {name:"Surplus", value:Math.max(net,0),color:"var(--green)"},
    ...(net<0?[{name:"Overspend",value:Math.abs(net),color:"var(--red)"}]:[])
  ].filter(d=>d.value>0) : [{name:"No data",value:1,color:"var(--brd)"}];

  const updateSal  = (mi,val) => { const ns={...sal,[mi]:val?parseInt(val):0}; setSal(ns); persist({[`${person}Sal`]:ns}); };
  const toggleInv  = (id,mi) => {
    const cur=invSt[id]?.[mi]?.status||"Pending"; const next=STATUSES[(STATUSES.indexOf(cur)+1)%STATUSES.length];
    const ts=new Date().toISOString(); const nst={...invSt,[id]:{...(invSt[id]||{}),[mi]:{status:next,ts}}};
    setInvSt(nst); const nl=[{ts,name:inv.find(i=>i.id===id)?.name||id,type:"inv",month:MONTHS[mi],from:cur,to:next},...changeLog].slice(0,60);
    setChangeLog(nl); persist({[`${person}InvSt`]:nst,log:nl});
  };
  const toggleExp  = (id,mi) => {
    const cur=expSt[id]?.[mi]?.status||"Pending"; const next=STATUSES[(STATUSES.indexOf(cur)+1)%STATUSES.length];
    const ts=new Date().toISOString(); const nst={...expSt,[id]:{...(expSt[id]||{}),[mi]:{status:next,ts}}};
    setExpSt(nst); persist({[`${person}ExpSt`]:nst});
  };
  const updateNote = (id,val) => { const n={...notes,[id]:val}; setNotes(n); persist({notes:n}); };
  const updateInv  = (id,f,v) => { const l=inv.map(i=>i.id===id?{...i,[f]:f==="amount"?parseInt(v)||0:v}:i); setInv(l); persist({[`${person}Inv`]:l}); };
  const updateExp  = (id,f,v) => { const l=exp.map(e=>e.id===id?{...e,[f]:f==="amount"?parseInt(v)||0:v}:e); setExp(l); persist({[`${person}Exp`]:l}); };
  const addInv = () => {
    if(!newInv.name||!newInv.amount) return;
    const item={id:`${person}i${uid()}`,name:newInv.name,category:newInv.category,amount:parseInt(newInv.amount)||0};
    const l=[...inv,item]; setInv(l); persist({[`${person}Inv`]:l}); setNewInv({name:"",category:"SIP",amount:""}); setModal(null);
  };
  const addExp = () => {
    if(!newExp.name||!newExp.amount) return;
    const item={id:`${person}e${uid()}`,name:newExp.name,amount:parseInt(newExp.amount)||0,cat:newExp.cat};
    const l=[...exp,item]; setExp(l); persist({[`${person}Exp`]:l}); setNewExp({name:"",amount:"",cat:"Housing"}); setModal(null);
  };
  const delInv = id => { const l=inv.filter(i=>i.id!==id); setInv(l); persist({[`${person}Inv`]:l}); };
  const delExp = id => { const l=exp.filter(e=>e.id!==id); setExp(l); persist({[`${person}Exp`]:l}); };

  const metrics = [
    {label:"Take-Home",   val:salary,   sub:salary?`${fmtF(salary)} / mo`:"Set salary ↓", acc:color},
    {label:"Invested",    val:totalInv, sub:`${inv.length} instruments`,                   acc:"var(--gold)"},
    {label:"Expenses",    val:totalExp, sub:`${exp.length} line items`,                    acc:"var(--blue)"},
    ...(net>=0
      ? [{label:"Net Surplus", val:net, sub:salary>0?`${Math.round(net/salary*100)}% of income`:"—", acc:"var(--green)"}]
      : [{label:"Overspend",   val:Math.abs(net), sub:"review expenses", acc:"var(--red)"}]
    ),
    {label:"Savings Rate", val:`${savR}%`, text:true, sub:savR>=30?"Excellent":"Target: 30%+", acc:savR>=30?"var(--green)":savR>=20?"var(--gold)":"var(--red)"},
  ];

  return (
    <div className="fu">
      {/* Metric cards */}
      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(158px,1fr))",gap:12,marginBottom:22}}>
        {metrics.map(({label,val,sub,acc,text})=>(
          <div key={label} className="mc" style={{"--acc":acc}}>
            <div className="lbl" style={{marginBottom:10}}>{label}</div>
            <div className="cg" style={{fontSize:30,color:acc,fontWeight:400,lineHeight:1}}>{text?val:fmt(val)}</div>
            <div className="out" style={{fontSize:11,color:"var(--dim)",marginTop:8}}>{sub}</div>
          </div>
        ))}
      </div>

      {/* Row: Donut + Zerodha/Allocation */}
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:16,marginBottom:20}}>
        <div className="card" style={{padding:"24px"}}>
          <div className="lbl" style={{marginBottom:16}}>Income Breakdown · {MONTHS[CM]}</div>
          {salary===0 ? (
            <div className="out" style={{fontSize:14,color:"var(--dim)",textAlign:"center",padding:"40px 0"}}>Enter your salary below to see breakdown</div>
          ) : (
            <div style={{display:"flex",gap:24,alignItems:"center"}}>
              <ResponsiveContainer width="44%" height={170}>
                <PieChart>
                  <Pie data={donutData} cx="50%" cy="50%" innerRadius={50} outerRadius={78} paddingAngle={3} dataKey="value">
                    {donutData.map((d,i)=><Cell key={i} fill={d.color} stroke="var(--card)" strokeWidth={2}/>)}
                  </Pie>
                  <Tooltip formatter={v=>[fmtF(v),""]} contentStyle={{background:"var(--card)",border:"1px solid var(--brd2)",borderRadius:10,fontFamily:"IBM Plex Mono",fontSize:12,boxShadow:"0 4px 12px rgba(0,0,0,.1)"}}/>
                </PieChart>
              </ResponsiveContainer>
              <div style={{flex:1,display:"flex",flexDirection:"column",gap:12}}>
                {donutData.map(d=>(
                  <div key={d.name}>
                    <div style={{display:"flex",justifyContent:"space-between",marginBottom:5}}>
                      <div style={{display:"flex",alignItems:"center",gap:7}}>
                        <div style={{width:7,height:7,borderRadius:2,background:d.color,flexShrink:0}}/>
                        <span className="out" style={{fontSize:12,color:"var(--sub)",fontWeight:500}}>{d.name}</span>
                      </div>
                      <span className="mono" style={{fontSize:12,color:d.color,fontWeight:500}}>{fmtF(d.value)}</span>
                    </div>
                    <div className="pb"><div className="pf" style={{width:`${Math.min((d.value/salary)*100,100)}%`,background:d.color}}/></div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
        {person==="neha"
          ? <ZerodhaSection kite={kite} setKite={setKite} persist={persist}/>
          : (
            <div className="card" style={{padding:"24px"}}>
              <div className="lbl" style={{marginBottom:16}}>Investment Mix</div>
              {inv.length>0 ? (()=>{
                const data=INV_CATS.map(c=>({name:c,value:inv.filter(i=>i.category===c).reduce((s,i)=>s+i.amount,0),color:CAT_CLR[c]})).filter(d=>d.value>0);
                return (
                  <div style={{display:"flex",gap:20,alignItems:"center"}}>
                    <ResponsiveContainer width="44%" height={170}>
                      <PieChart>
                        <Pie data={data} cx="50%" cy="50%" innerRadius={50} outerRadius={78} paddingAngle={3} dataKey="value">
                          {data.map((d,i)=><Cell key={i} fill={d.color} stroke="var(--card)" strokeWidth={2}/>)}
                        </Pie>
                        <Tooltip formatter={v=>[fmtF(v),""]} contentStyle={{background:"var(--card)",border:"1px solid var(--brd2)",borderRadius:10,fontFamily:"IBM Plex Mono",fontSize:12}}/>
                      </PieChart>
                    </ResponsiveContainer>
                    <div style={{flex:1,display:"flex",flexDirection:"column",gap:9}}>
                      {data.map(d=>(<div key={d.name} style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                        <div style={{display:"flex",alignItems:"center",gap:6}}><div style={{width:7,height:7,borderRadius:2,background:d.color}}/><span className="out" style={{fontSize:12,color:"var(--sub)",fontWeight:500}}>{d.name}</span></div>
                        <span className="mono" style={{fontSize:12,color:d.color,fontWeight:500}}>{fmt(d.value)}</span>
                      </div>))}
                    </div>
                  </div>
                );
              })() : <div className="out" style={{fontSize:14,color:"var(--dim)",textAlign:"center",padding:"40px 0"}}>No investments yet</div>}
            </div>
          )
        }
      </div>

      {/* Insights row: Investment + Expense side by side */}
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:16,marginBottom:20}}>
        <div className="card" style={{padding:"24px"}}>
          <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:16}}>
            <div className="cg" style={{fontSize:20,color:"var(--gold)",fontWeight:400}}>Investment Insights</div>
            <span className="badge" style={{background:`${color}14`,color,border:`1px solid ${color}30`}}>{fmtF(totalInv)}/mo</span>
          </div>
          <InvestmentInsights inv={inv} salary={salary} color={color}/>
        </div>
        <div className="card" style={{padding:"24px"}}>
          <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:16}}>
            <div className="cg" style={{fontSize:20,color:"var(--blue)",fontWeight:400}}>Expense Insights</div>
            <span className="badge" style={{background:"rgba(42,127,168,.1)",color:"var(--blue)",border:"1px solid rgba(42,127,168,.2)"}}>{fmtF(totalExp)}/mo</span>
          </div>
          <ExpenseInsights exp={exp} salary={salary}/>
        </div>
      </div>

      {/* Salary grid */}
      <div className="card" style={{padding:"22px",marginBottom:16}}>
        <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",cursor:"pointer"}} onClick={()=>setSalOpen(v=>!v)}>
          <div className="lbl">Monthly Take-Home Salary</div>
          <span className="mono" style={{fontSize:9,color:"var(--dim)"}}>{salOpen?"▲":"▼"}</span>
        </div>
        {salOpen&&(
          <div style={{overflowX:"auto",marginTop:18}}>
            <table style={{borderCollapse:"collapse",minWidth:720,width:"100%"}}>
              <thead><tr>
                {MONTHS.map((m,i)=>(
                  <th key={m} style={{padding:"6px 3px",minWidth:74,background:i===CM?`${color}0D`:"transparent",borderRadius:6,textAlign:"center"}}>
                    <span className="out" style={{fontSize:10,color:i===CM?color:"var(--dim)",fontWeight:i===CM?700:400,letterSpacing:".08em"}}>{m}</span>
                  </th>
                ))}
                <th style={{padding:"6px 10px",textAlign:"center"}}><span className="out" style={{fontSize:10,color:"var(--dim)"}}>Avg</span></th>
              </tr></thead>
              <tbody><tr>
                {MONTHS.map((_,i)=>{const v=sal[i]||""; return (
                  <td key={i} style={{padding:"4px 3px",textAlign:"center",background:i===CM?`${color}07`:"transparent"}}>
                    <input type="number" className={`si${v?" hv":""}`} placeholder="—" value={v} onChange={e=>updateSal(i,e.target.value)} style={i===CM?{borderColor:`${color}30`}:{}}/>
                  </td>
                );})}
                <td style={{padding:"4px 10px",textAlign:"center"}}><span className="mono" style={{fontSize:12,color,fontWeight:500}}>{fmt(MONTHS.reduce((s,_,i)=>s+(sal[i]||0),0)/Math.max(MONTHS.filter((_,i)=>sal[i]).length,1))}</span></td>
              </tr></tbody>
            </table>
          </div>
        )}
      </div>

      {/* Investments tracker */}
      <div className="card" style={{padding:"24px",marginBottom:14}}>
        <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:invOpen?18:0,cursor:"pointer"}} onClick={()=>setInvOpen(v=>!v)}>
          <div style={{display:"flex",alignItems:"center",gap:16}}>
            <div className="lbl">Investments</div>
            <div className="cg" style={{fontSize:22,color,fontWeight:400}}>{fmtF(totalInv)}<span className="out" style={{fontSize:12,color:"var(--dim)",marginLeft:5,fontWeight:400}}>/mo</span></div>
          </div>
          <div style={{display:"flex",alignItems:"center",gap:10}}>
            <button className="gh" style={{fontSize:12,padding:"6px 14px"}} onClick={e=>{e.stopPropagation();setModal("addInv");}}>+ Add</button>
            <span className="mono" style={{fontSize:9,color:"var(--dim)"}}>{invOpen?"▲":"▼"}</span>
          </div>
        </div>
        {invOpen&&<TrackerTable rows={inv} statusMap={invSt} notes={notes} onToggle={toggleInv} onNote={updateNote} onDelete={delInv} onUpdate={updateInv} groupKey="category" groups={INV_CATS} tagColors={CAT_CLR} accent={color}/>}
      </div>

      {/* Expenses tracker */}
      <div className="card" style={{padding:"24px"}}>
        <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:expOpen?18:0,cursor:"pointer"}} onClick={()=>setExpOpen(v=>!v)}>
          <div style={{display:"flex",alignItems:"center",gap:16}}>
            <div className="lbl">Expenses</div>
            <div className="cg" style={{fontSize:22,color:"var(--blue)",fontWeight:400}}>{fmtF(totalExp)}<span className="out" style={{fontSize:12,color:"var(--dim)",marginLeft:5,fontWeight:400}}>/mo</span></div>
          </div>
          <div style={{display:"flex",alignItems:"center",gap:10}}>
            <button className="gh" style={{fontSize:12,padding:"6px 14px"}} onClick={e=>{e.stopPropagation();setModal("addExp");}}>+ Add</button>
            <span className="mono" style={{fontSize:9,color:"var(--dim)"}}>{expOpen?"▲":"▼"}</span>
          </div>
        </div>
        {expOpen&&<TrackerTable rows={exp} statusMap={expSt} notes={notes} onToggle={toggleExp} onNote={updateNote} onDelete={delExp} onUpdate={updateExp} groupKey="cat" groups={EXP_CATS} tagColors={EXP_CLR} accent="var(--blue)"/>}
      </div>

      {/* Modals */}
      {modal==="addInv"&&<div className="mbg" onClick={e=>{if(e.target===e.currentTarget)setModal(null);}}>
        <div className="mbox">
          <div className="cg" style={{fontSize:26,color,fontWeight:400,marginBottom:20}}>Add Investment</div>
          <div style={{display:"flex",flexDirection:"column",gap:12}}>
            <input className="inp" placeholder="e.g. Nifty BeES, SGB, Parag Parikh Fund" value={newInv.name} onChange={e=>setNewInv(n=>({...n,name:e.target.value}))}/>
            <select className="inp" value={newInv.category} onChange={e=>setNewInv(n=>({...n,category:e.target.value}))}>{INV_CATS.map(c=><option key={c}>{c}</option>)}</select>
            <input className="inp" type="number" placeholder="Monthly SIP / contribution (₹)" value={newInv.amount} onChange={e=>setNewInv(n=>({...n,amount:e.target.value}))}/>
            <div style={{display:"flex",gap:10,marginTop:4}}><button className="bg" style={{flex:1}} onClick={addInv}>Add Investment</button><button className="gh" style={{flex:1}} onClick={()=>setModal(null)}>Cancel</button></div>
          </div>
        </div>
      </div>}

      {modal==="addExp"&&<div className="mbg" onClick={e=>{if(e.target===e.currentTarget)setModal(null);}}>
        <div className="mbox">
          <div className="cg" style={{fontSize:26,color:"var(--blue)",fontWeight:400,marginBottom:20}}>Add Expense</div>
          <div style={{display:"flex",flexDirection:"column",gap:12}}>
            <input className="inp" placeholder="Expense name" value={newExp.name} onChange={e=>setNewExp(n=>({...n,name:e.target.value}))}/>
            <select className="inp" value={newExp.cat} onChange={e=>setNewExp(n=>({...n,cat:e.target.value}))}>{EXP_CATS.map(c=><option key={c}>{c}</option>)}</select>
            <input className="inp" type="number" placeholder="Monthly amount (₹)" value={newExp.amount} onChange={e=>setNewExp(n=>({...n,amount:e.target.value}))}/>
            <div style={{display:"flex",gap:10,marginTop:4}}><button className="bg bg-blue" style={{flex:1}} onClick={addExp}>Add Expense</button><button className="gh" style={{flex:1}} onClick={()=>setModal(null)}>Cancel</button></div>
          </div>
        </div>
      </div>}

      <button className="fa" style={{background:`linear-gradient(135deg, ${color}, ${color}AA)`}} onClick={()=>setModal("addInv")}>+</button>
    </div>
  );
}

// ─── Combined Tab ─────────────────────────────────────────────────────────────
function CombinedTab({ nehaS, sanketS, nehaInv, sanketInv, nehaExp, sanketExp, nehaSal, sanketSal, nehaKite }) {
  const totalSal   = nehaS+sanketS;
  const nehaInvT   = sumAmt(nehaInv); const sanketInvT = sumAmt(sanketInv);
  const nehaExpT   = sumAmt(nehaExp); const sanketExpT = sumAmt(sanketExp);
  const totalInv   = nehaInvT+sanketInvT;
  const totalExp   = nehaExpT+sanketExpT;
  const net        = totalSal-totalInv-totalExp;
  const savR       = totalSal>0 ? Math.round(totalInv/totalSal*100) : 0;
  const kiteTotal  = (nehaKite.holdings||[]).reduce((s,h)=>s+(h.last_price||0)*h.quantity,0);

  const allInv    = [...nehaInv,...sanketInv];
  const allocData = INV_CATS.map(c=>({name:c,value:allInv.filter(i=>i.category===c).reduce((s,i)=>s+i.amount,0),color:CAT_CLR[c]})).filter(d=>d.value>0);
  const barData   = MONTHS.map((m,i)=>({m,neha:nehaSal[i]||0,sanket:sanketSal[i]||0})).filter(d=>d.neha||d.sanket);
  const proj10yr  = Math.round(totalInv*12*((Math.pow(1.12,10)-1)/0.01));

  const combinedMetrics = [
    {label:"Combined Income",   val:totalSal, sub:`N: ${fmt(nehaS)} · S: ${fmt(sanketS)}`, acc:"var(--gold)"},
    {label:"Joint Investments", val:totalInv, sub:`N: ${fmt(nehaInvT)} · S: ${fmt(sanketInvT)}`, acc:"var(--gold)"},
    {label:"Joint Expenses",    val:totalExp, sub:`N: ${fmt(nehaExpT)} · S: ${fmt(sanketExpT)}`, acc:"var(--blue)"},
    ...(net>=0
      ? [{label:"Net Surplus",   val:net, sub:totalSal>0?`${Math.round(net/totalSal*100)}% of income`:"—", acc:"var(--green)"}]
      : [{label:"Net Overspend", val:Math.abs(net), sub:"combined budget exceeded", acc:"var(--red)"}]
    ),
    {label:"Savings Rate", val:`${savR}%`, text:true, sub:`Target: 30%+`, acc:savR>=30?"var(--green)":savR>=20?"var(--gold)":"var(--red)"},
    ...(kiteTotal?[{label:"Zerodha Equity",val:kiteTotal,sub:"Neha's live portfolio",acc:"var(--green)"}]:[]),
  ];

  return (
    <div className="fu">
      {/* Metrics */}
      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(158px,1fr))",gap:12,marginBottom:24}}>
        {combinedMetrics.map(({label,val,sub,acc,text})=>(
          <div key={label} className="mc" style={{"--acc":acc}}>
            <div className="lbl" style={{marginBottom:10}}>{label}</div>
            <div className="cg" style={{fontSize:30,color:acc,fontWeight:400,lineHeight:1}}>{text?val:fmt(val)}</div>
            <div className="out" style={{fontSize:11,color:"var(--dim)",marginTop:8}}>{sub}</div>
          </div>
        ))}
      </div>

      {/* Charts */}
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:16,marginBottom:20}}>
        <div className="card" style={{padding:"24px"}}>
          <div className="lbl" style={{marginBottom:16}}>Joint Investment Allocation</div>
          {allocData.length===0
            ? <div className="out" style={{fontSize:14,color:"var(--dim)",textAlign:"center",padding:"40px 0"}}>No investment data</div>
            : <div style={{display:"flex",gap:20,alignItems:"center"}}>
                <ResponsiveContainer width="44%" height={180}>
                  <PieChart>
                    <Pie data={allocData} cx="50%" cy="50%" innerRadius={52} outerRadius={80} paddingAngle={3} dataKey="value">
                      {allocData.map((d,i)=><Cell key={i} fill={d.color} stroke="var(--card)" strokeWidth={2}/>)}
                    </Pie>
                    <Tooltip formatter={v=>[fmtF(v),""]} contentStyle={{background:"var(--card)",border:"1px solid var(--brd2)",borderRadius:10,fontFamily:"IBM Plex Mono",fontSize:12,boxShadow:"0 4px 12px rgba(0,0,0,.1)"}}/>
                  </PieChart>
                </ResponsiveContainer>
                <div style={{flex:1,display:"flex",flexDirection:"column",gap:9}}>
                  {allocData.map(d=>(
                    <div key={d.name}>
                      <div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}>
                        <div style={{display:"flex",alignItems:"center",gap:6}}>
                          <div style={{width:7,height:7,borderRadius:2,background:d.color}}/>
                          <span className="out" style={{fontSize:12,color:"var(--sub)",fontWeight:500}}>{d.name}</span>
                        </div>
                        <span className="mono" style={{fontSize:12,color:d.color,fontWeight:500}}>{fmt(d.value)}</span>
                      </div>
                      <div className="pb-thin"><div className="pf-thin" style={{width:`${totalInv>0?Math.round(d.value/totalInv*100):0}%`,background:d.color}}/></div>
                    </div>
                  ))}
                </div>
              </div>
          }
        </div>

        <div className="card" style={{padding:"24px"}}>
          <div className="lbl" style={{marginBottom:16}}>Monthly Income · Neha vs Sanket</div>
          {barData.length===0
            ? <div className="out" style={{fontSize:14,color:"var(--dim)",textAlign:"center",padding:"40px 0"}}>Enter salary figures in each tab</div>
            : <ResponsiveContainer width="100%" height={180}>
                <BarChart data={barData} barSize={9} barGap={3}>
                  <XAxis dataKey="m" tick={{fontFamily:"IBM Plex Mono",fontSize:9,fill:"var(--dim)"}} axisLine={false} tickLine={false}/>
                  <YAxis hide/>
                  <Tooltip contentStyle={{background:"var(--card)",border:"1px solid var(--brd2)",borderRadius:10,fontFamily:"IBM Plex Mono",fontSize:12,boxShadow:"0 4px 12px rgba(0,0,0,.1)"}} formatter={v=>[fmtF(v),""]}/>
                  <Bar dataKey="neha" name="Neha" fill="#B07D2A" radius={[4,4,0,0]}/>
                  <Bar dataKey="sanket" name="Sanket" fill="#2A7FA8" radius={[4,4,0,0]}/>
                </BarChart>
              </ResponsiveContainer>
          }
        </div>
      </div>

      {/* 10yr projection banner */}
      {totalInv>0&&(
        <div style={{background:"linear-gradient(135deg, rgba(176,125,42,.08), rgba(176,125,42,.03))",border:"1px solid rgba(176,125,42,.2)",borderRadius:18,padding:"24px 28px",marginBottom:20,display:"flex",alignItems:"center",justifyContent:"space-between"}}>
          <div>
            <div className="lbl" style={{marginBottom:8}}>10-Year Wealth Projection @ 12% CAGR</div>
            <div className="cg" style={{fontSize:40,color:"var(--gold)",fontWeight:400,lineHeight:1}}>{fmt(proj10yr)}</div>
            <div className="out" style={{fontSize:13,color:"var(--sub)",marginTop:6}}>If both of you keep investing {fmtF(totalInv)} every month without stopping</div>
          </div>
          <div style={{textAlign:"right"}}>
            <div className="lbl" style={{marginBottom:6}}>Monthly SIP</div>
            <div className="cg" style={{fontSize:26,color:"var(--sub)",fontWeight:400}}>{fmtF(totalInv)}</div>
            <div className="out" style={{fontSize:11,color:"var(--dim)",marginTop:4}}>Savings rate: {savR}%</div>
          </div>
        </div>
      )}

      <AIInsights data={{nehaS,sanketS,nehaInvT,sanketInvT,nehaExpT,sanketExpT,totalInv,totalExp,net,nehaInv,sanketInv,nehaExp,sanketExp,kiteTotal}}/>
    </div>
  );
}

// ─── Export ───────────────────────────────────────────────────────────────────
function exportData(state) {
  const payload = {exportedAt:new Date().toISOString(),version:"v6",...state};
  const blob = new Blob([JSON.stringify(payload,null,2)],{type:"application/json"});
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement("a");
  a.href=url; a.download=`portfolio-backup-${new Date().toISOString().slice(0,10)}.json`;
  a.click(); URL.revokeObjectURL(url);
}

// ─── Root ─────────────────────────────────────────────────────────────────────
export default function Dashboard() {
  const [tab,         setTab]         = useState("combined");
  const [nehaInv,     setNehaInv]     = useState([]);
  const [sanketInv,   setSanketInv]   = useState([]);
  const [nehaExp,     setNehaExp]     = useState([]);
  const [sanketExp,   setSanketExp]   = useState([]);
  const [nehaInvSt,   setNehaInvSt]   = useState({});
  const [sanketInvSt, setSanketInvSt] = useState({});
  const [nehaExpSt,   setNehaExpSt]   = useState({});
  const [sanketExpSt, setSanketExpSt] = useState({});
  const [notes,       setNotes]       = useState({});
  const [nehaSal,     setNehaSal]     = useState({});
  const [sanketSal,   setSanketSal]   = useState({});
  const [nehaKite,    setNehaKite]    = useState({...KITE_INIT});
  const [changeLog,   setChangeLog]   = useState([]);
  const [lastSaved,   setLastSaved]   = useState(null);
  const [loaded,      setLoaded]      = useState(false);
  const [storageOk,   setStorageOk]   = useState(true);

  useEffect(()=>{
    (()=>{
      const g = k => { try { const r=localStorage.getItem(k); return r?JSON.parse(r):null; } catch { return null; } };
      try {
        setNehaInv(     g("v6:nehaInv")     || D_NEHA_INV);
        setSanketInv(   g("v6:sanketInv")   || D_SANKET_INV);
        setNehaExp(     g("v6:nehaExp")      || D_NEHA_EXP);
        setSanketExp(   g("v6:sanketExp")    || D_SANKET_EXP);
        setNehaInvSt(   g("v6:nehaInvSt")   || {});
        setSanketInvSt( g("v6:sanketInvSt") || {});
        setNehaExpSt(   g("v6:nehaExpSt")   || {});
        setSanketExpSt( g("v6:sanketExpSt") || {});
        setNotes(       g("v6:notes")        || {});
        setNehaSal(     g("v6:nehaSal")      || {});
        setSanketSal(   g("v6:sanketSal")    || {});
        const nk = g("v6:nehaKite"); if(nk) setNehaKite(nk);
        setChangeLog(   g("v6:log")          || []);
        const ls = g("v6:saved"); if(ls) setLastSaved(ls);
        setStorageOk(true);
      } catch { setStorageOk(false); }
      setLoaded(true);
    })();
  },[]);

  const persist = useCallback(patch => {
    const ts = new Date().toISOString();
    for(const [k,v] of Object.entries(patch)) {
      try { if(v!==undefined) localStorage.setItem(`v6:${k}`,JSON.stringify(v)); } catch {}
    }
    try { localStorage.setItem("v6:saved",JSON.stringify(ts)); } catch {}
    setLastSaved(ts);
  },[]);

  if(!loaded) return (
    <div style={{background:"var(--bg)",minHeight:"100vh",display:"flex",alignItems:"center",justifyContent:"center"}}>
      <div className="cg" style={{fontSize:28,color:"var(--gold)",fontWeight:300,letterSpacing:".06em",opacity:.6}}>Loading…</div>
    </div>
  );

  const nehaS   = nehaSal[CM]  ||0;
  const sanketS = sanketSal[CM]||0;
  const allState = {nehaInv,sanketInv,nehaExp,sanketExp,nehaInvSt,sanketInvSt,nehaExpSt,sanketExpSt,notes,nehaSal,sanketSal,changeLog};

  return (
    <div style={{background:"var(--bg)",minHeight:"100vh",color:"var(--text)"}}>
      <style>{CSS}</style>

      {/* Header */}
      <div style={{background:"var(--card)",borderBottom:"1px solid var(--brd)",padding:"14px 32px",display:"flex",alignItems:"center",justifyContent:"space-between",position:"sticky",top:0,zIndex:50,boxShadow:"0 1px 8px rgba(60,40,10,.06)"}}>
        <div style={{display:"flex",alignItems:"baseline",gap:16}}>
          <div className="cg" style={{fontSize:24,color:"var(--gold)",fontWeight:400,letterSpacing:".03em"}}>Portfolio</div>
          <div className="lbl" style={{fontSize:9,letterSpacing:".16em"}}>Family Finance · {MONTHS[CM]} {CY}</div>
        </div>
        <div style={{display:"flex",alignItems:"center",gap:12}}>
          {!storageOk&&<span className="out badge" style={{background:"rgba(184,64,64,.08)",color:"var(--red)",border:"1px solid rgba(184,64,64,.2)"}}>⚠ Storage unavailable</span>}
          {lastSaved&&<span className="out" style={{fontSize:11,color:"var(--dim)"}}>{fmtSv(lastSaved)}</span>}
          <button className="gh" style={{fontSize:12,padding:"7px 16px"}} onClick={()=>exportData(allState)}>↓ Export</button>
        </div>
      </div>

      {/* Tabs */}
      <div style={{background:"var(--card)",borderBottom:"1px solid var(--brd)",display:"flex",padding:"0 26px"}}>
        {[["neha","Neha","an"],["sanket","Sanket","as"],["combined","Combined","ac"]].map(([t,label,cls])=>(
          <button key={t} className={`tab${tab===t?` ${cls}`:""}`} onClick={()=>setTab(t)}>{label}</button>
        ))}
      </div>

      {/* Page */}
      <div style={{maxWidth:1380,margin:"0 auto",padding:"28px 20px 100px"}}>
        {tab==="neha"&&<PersonTab person="neha" salary={nehaS}
          inv={nehaInv} setInv={setNehaInv} exp={nehaExp} setExp={setNehaExp}
          invSt={nehaInvSt} setInvSt={setNehaInvSt} expSt={nehaExpSt} setExpSt={setNehaExpSt}
          sal={nehaSal} setSal={setNehaSal} kite={nehaKite} setKite={setNehaKite}
          notes={notes} setNotes={setNotes} changeLog={changeLog} setChangeLog={setChangeLog} persist={persist}/>}
        {tab==="sanket"&&<PersonTab person="sanket" salary={sanketS}
          inv={sanketInv} setInv={setSanketInv} exp={sanketExp} setExp={setSanketExp}
          invSt={sanketInvSt} setInvSt={setSanketInvSt} expSt={sanketExpSt} setExpSt={setSanketExpSt}
          sal={sanketSal} setSal={setSanketSal} kite={nehaKite} setKite={setNehaKite}
          notes={notes} setNotes={setNotes} changeLog={changeLog} setChangeLog={setChangeLog} persist={persist}/>}
        {tab==="combined"&&<CombinedTab nehaS={nehaS} sanketS={sanketS}
          nehaInv={nehaInv} sanketInv={sanketInv} nehaExp={nehaExp} sanketExp={sanketExp}
          nehaSal={nehaSal} sanketSal={sanketSal} nehaKite={nehaKite}/>}
      </div>
    </div>
  );
}
